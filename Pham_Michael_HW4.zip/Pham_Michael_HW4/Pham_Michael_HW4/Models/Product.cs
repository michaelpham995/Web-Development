﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Pham_Michael_HW4.DAL;
using Microsoft.AspNetCore.Identity;


namespace Pham_Michael_HW4.Models
{
    public enum Types { Hat, Pants, Sweatshirt, Tank, TShirt, Other}
    public class Product 
    {
        public Int32 ProductID { get; set; }
        [Required(ErrorMessage = "Product name is required!")]
        [Display(Name = "Product Name:")]
        public String Name { get; set; }
        [Display(Name = "Product Description:")]
        public String Description { get; set; }
        [Required(ErrorMessage = "Product price is required!")]
        [Display(Name = "Product Price:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Price { get; set; }
        [Display(Name = "Product Type:")]
        public Types ProductType { get; set; }
    }
}
