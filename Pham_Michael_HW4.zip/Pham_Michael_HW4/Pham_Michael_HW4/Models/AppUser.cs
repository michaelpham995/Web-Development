﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;



namespace Pham_Michael_HW4.Models
{
    public class AppUser : IdentityUser
    {
        //First name is provided as an example
        [Required(ErrorMessage = "First name is required!")]
        [Display(Name = "First Name:")]
        public String FirstName { get; set; }
        [Required(ErrorMessage = "Last name is required!")]
        [Display(Name = "Last Name:")]
        public String LastName { get; set; }

        //nuclear option
    }
}
