﻿using Microsoft.AspNetCore.Mvc;

namespace Pham_Michael_HW4.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
