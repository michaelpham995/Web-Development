﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace Pham_Michael_HW5.Models
{
    public class OrderDetail 
    {
        public Int32 OrderDetailID { get; set; }

        [Required(ErrorMessage = "You must specify a quantity to order:")]
        [Display(Name = "Quantity of Product:")]
        [Range(1, 1000, ErrorMessage = "Number of products must be between 1 and 1000")]
        public Int32 Quantity { get; set; }
        [Display(Name = "Product Price:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal ProductPrice { get; set; }
        [Display(Name = "Total Price:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal TotalPrice { get; set; }


        public Order Order { get; set; }
        public Product Product { get; set; }


        public void ExtendedPrice()
        {
            TotalPrice = ProductPrice * Quantity;
            if(TotalPrice == 0)
            {
                throw new Exception("Total items must be greater than 0.");
            }
        }

    }
}
