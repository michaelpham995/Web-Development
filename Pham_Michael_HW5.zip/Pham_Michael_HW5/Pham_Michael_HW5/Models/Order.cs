﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web;



namespace Pham_Michael_HW5.Models
{
    public class Order 
    {

        public Decimal SALES_TAX = 0.0825m;
        public Int32 OrderID { get; set; }
        [Display(Name = "Order Number:")]
        public Int32 OrderNumber { get; set; }
        [Display(Name = "Order Date:")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime OrderDate { get; set; }
        [Display(Name = "Order Notes:")]
        public String OrderNotes { get; set; }

        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal OrderSubtotal
        {
            get { return OrderDetails.Sum(rd => rd.TotalPrice); }
        }

        [Display(Name = "Tax(8.25%)")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal TaxFee
        {
            get { return OrderSubtotal * SALES_TAX; }
        }

        [Display(Name = "Order Total")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal OrderTotal
        {
            get { return OrderSubtotal + TaxFee; }
        }


        public List<OrderDetail> OrderDetails { get; set; }

        public AppUser Customer { get; set; }

        public Order()
        {
            if (OrderDetails == null) 
            {
                OrderDetails = new List<OrderDetail>();
            }
        }
    }
}
