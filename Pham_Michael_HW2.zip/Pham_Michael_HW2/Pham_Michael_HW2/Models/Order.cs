﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;


namespace Pham_Michael_HW2.Models
{

        public enum CustomerType { Group, Individual } //This sets the Customer Type to either group or indiviudal based on link clicked

        public abstract class Order
        {
            //The constants are set below for prices
            const Decimal SWEATSHIRT_PRICE = 15m;
            const Decimal TSHIRT_PRICE = 10m;

            //Below is the display for customer inputs with error messages and code
            [Display(Name = "Customer Code:")]
            [StringLength(6, MinimumLength = 4, ErrorMessage = "The code must be between 4 and 6 characters in length.")]
            [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "The code must be in letters only.")]
            public string CustomerCode { get; set; }

            [Display(Name = "Customer Type:")]
            public Enum CustomerType { get; set; }

            [Display(Name = "Number of Sweatshirts:")]
            public Int32 NumberOfSweatshirts { get; set; }

            [Display(Name = "Number of T-Shirts:")]
            public Int32 NumberOfTShirts { get; set; }


            [Display(Name = "Total Items:")]
            public Int32 TotalItems { get; set; }


            [Display(Name = "Sweatshirt Subtotal:")]
            [DisplayFormat(DataFormatString = "{0:c}")]
            public Decimal SweatshirtSubtotal { get; private set; }

            [Display(Name = "T-Shirt Subtotal:")]
            [DisplayFormat(DataFormatString = "{0:c}")]
            public Decimal TShirtSubtotal { get; private set; }

            [Display(Name = "Subtotal:")]
            [DisplayFormat(DataFormatString = "{0:c}")]
            public Decimal Subtotal { get; private set; }

            [Display(Name = "Total:")]
            [DisplayFormat(DataFormatString = "{0:c}")]
            public Decimal Total { get; set; }

            //Below is the calculate totals class that calculates the second views
            public void CalcSubtotals()
            {
                TotalItems = NumberOfSweatshirts + NumberOfTShirts;

                //Below makes sure you have items in your class
                if (TotalItems == 0)
                {
                    throw new Exception("Total items must be greater than 0.");

                }

                //Below is the calculations of other totals
                SweatshirtSubtotal = NumberOfSweatshirts * SWEATSHIRT_PRICE;
                TShirtSubtotal = NumberOfTShirts * TSHIRT_PRICE;
                Subtotal = SweatshirtSubtotal + TShirtSubtotal;


            }









        }




}
