﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace Pham_Michael_HW2.Models
{
    public class GroupOrder : Order
    {
        [Display(Name = "Is this a preferred customer?")]
        public Boolean PreferredCustomer { get; set; }

        [Display(Name = "Setup Fee:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal SetupFee { get; set; }

        //Below is calculations of totals and if the customer is preferred
        public void CalcTotals()
        {
            CalcSubtotals();

            if (PreferredCustomer == true)
            {
                SetupFee = 0;
            }
            if (Subtotal > 5000)
            {
                SetupFee = 0;
            }

            Total = Subtotal + SetupFee;
        }
        





    }
}
