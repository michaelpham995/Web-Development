﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Pham_Michael_HW2.Models
{


    public class IndividualOrder : Order
    {
        //Declare constants below
        const Decimal SALES_TAX_RATE = 0.0875m;
        const Decimal SWEATSHIRT_FEE = 2.50m;
        const Decimal TSHIRT_FEE = 2.00m;

        //User output/input
        [Display(Name = "Customer Name:")]
        public String CustomerName { get; set; }

        [Display(Name = "Processing Fee:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal ProcessingFee { get; set; }


        [Display(Name = "Sales Tax:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal SalesTax { get; set; }

        //Calculations are below
        public void CalcTotals()
        {
            CalcSubtotals();
            ProcessingFee = (NumberOfSweatshirts * SWEATSHIRT_FEE) + (NumberOfTShirts * TSHIRT_FEE);
            SalesTax = (Subtotal + ProcessingFee) * SALES_TAX_RATE;
            Total = Subtotal + ProcessingFee + SalesTax;

        }







    }
}
