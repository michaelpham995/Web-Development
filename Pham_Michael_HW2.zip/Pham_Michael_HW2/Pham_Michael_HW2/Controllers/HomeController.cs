﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using System.ComponentModel.DataAnnotations;
using Pham_Michael_HW2.Models;

namespace Pham_Michael_HW2.Controllers
{
    public class HomeController : Controller

    {

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult CheckoutGroup()
        {
            return View();
        }

        public IActionResult GroupTotals(GroupOrder groupOrder)
        {
            TryValidateModel(groupOrder);
            if (ModelState.IsValid == false)
            {
                return View("CheckoutGroup", groupOrder);
            }

            try
            {
                groupOrder.CalcTotals();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                return View("CheckoutGroup", groupOrder);
            }

            groupOrder.CustomerType = CustomerType.Group;
            return View("GroupTotals", groupOrder);
        }

        public IActionResult CheckOutIndividual()
        {
            return View();
        }

        public  IActionResult IndividualTotals(IndividualOrder individualOrder)
        {
            TryValidateModel(individualOrder);
            if (ModelState.IsValid == false)
            {
                return View("CheckoutIndividual", individualOrder);
            }

            try
            {
                individualOrder.CalcTotals();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                return View("CheckoutIndividual", individualOrder);
            }
            individualOrder.CustomerType = CustomerType.Group;
            return View("IndividualTotals", individualOrder);

        }



        



    }
}
